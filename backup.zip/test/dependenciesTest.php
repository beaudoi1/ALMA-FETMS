<?php
require_once('../SiteConfig.php');

//require($site_classes . '/class.cryostat.php');
//require($site_classes . '/class.cca.php');
//require($site_classes . '/class.wca.php');
//require($site_classes . '/class.fecomponent.php');
//require($site_classes . '/class.frontend.php');
//require($site_classes . '/class.testdata_header.php');
//require($site_classes . '/class.testdata_component.php');
//require($site_classes . '/class.dataplotter.php');
//require($site_classes . '/class.dboperations.php');
//require($site_classes . '/class.mixerparams.php');
//require($site_classes . '/class.ccapas.php');
//require($site_classes . '/class.tempsensor.php');
//require($site_classes . '/class.cidl_tcpdf.php');
//require($site_classes . '/class.eff.php');
//require($site_classes . '/class.scandetails.php');
//require($site_classes . '/class.scansetdetails.php');
//require($site_classes . '/class.finelosweep.php');
//require($site_classes . '/class.ifspectrumplotter.php');
require($site_classes . '/class.cca_image_rejection.php');
require($site_classes . '/class.noisetemp.php');



?>
