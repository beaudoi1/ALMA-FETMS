</div>
      <div class="sidebar" style="margin-left:30px">
        <div class="search">
            <?php
          echo "
            <form id='form' name='form' method='post' action= '" . $_SERVER['PHP_SELF'] . "'>";
          ?>
            <span>
            <input name="band_sn" type="text" class="keywords" id="textfield" maxlength="50" value="" />
            <input name="b" type="image" src="images/search.gif" class="button" />
            </span>
          </form>
        </div>
        <div class="gadget">
          <h2>Test Data Information</h2>
          <div class="clr"></div>
          <ul class="sb_menu">
            <li><a href="FEND-40.09.03.00-076-A-DSN.pdf">Data Formats</a></li>
            <li><a href="http://edm.alma.cl/forums/alma/dispatch.cgi/iptfedocs/showFolder/106541/def/def/9394174">ALMA EDM</a></li>
            <li><a href="example_data.zip">Example Data Set</a></li>
          </ul>
        </div>
        <div class="gadget">

        </div>
        <div class="gadget">

        </div>
      </div>
      <div class="clr"></div>
    </div>
  </div>

</div>
    <div class="footer">

      <div class="clr"></div>
    </div>
</body>
</html>